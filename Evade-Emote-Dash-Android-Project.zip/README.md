# Evade Emote Dash (alpha scaffold)

Projeto Android independente, preparado para compilar um APK de depuração pelo GitHub Actions.

## Estado real desta versão
- Tela inicial e permissões de sobreposição/Acessibilidade: incluídas.
- Botão flutuante arrastável: incluído.
- **Calibração de coordenadas, salvamento das posições e sequência emote 2 + agachar: ainda NÃO implementados.**
- Não é uma versão funcional de automação para jogar ainda; esta base serve para validar a compilação e a exibição do overlay antes de implementar e testar a automação.

## Compilar
1. Envie os arquivos deste projeto para um repositório GitHub novo.
2. Abra a aba **Actions**.
3. Se solicitado, habilite workflows.
4. Execute **Build Android APK** com **Run workflow**, ou faça push para `main`/`master`.
5. Baixe o artefato `Evade-Emote-Dash-debug-apk` da execução concluída.

O APK gerado é de depuração e não está assinado para publicação na Play Store.
