package com.noir.evadeemotedash

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        layout.addView(TextView(this).apply {
            text = "Evade Emote Dash\n\nVersão alfa"
            textSize = 24f
        })
        layout.addView(TextView(this).apply {
            text = "\n1. Conceda a permissão de sobreposição.\n2. Ative o serviço de Acessibilidade nas configurações.\n3. Abra o botão flutuante e calibre os controles dentro do Evade.\n\nA calibração e a sequência automática ainda precisam ser testadas no aparelho."
            textSize = 16f
        })
        layout.addView(Button(this).apply {
            text = "Permitir botão sobreposto"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Permissão já concedida", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(Button(this).apply {
            text = "Abrir Acessibilidade"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "Iniciar botão flutuante"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Conceda primeiro a permissão de sobreposição.", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, FloatingButtonService::class.java))
                    Toast.makeText(this@MainActivity, "Botão flutuante iniciado", Toast.LENGTH_SHORT).show()
                }
            }
        })
        setContentView(layout, ViewGroup.LayoutParams(-1, -1))
    }
}
