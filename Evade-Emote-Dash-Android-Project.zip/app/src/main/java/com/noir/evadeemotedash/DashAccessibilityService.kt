package com.noir.evadeemotedash

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent

class DashAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Base service only. Coordinate calibration and gesture sequencing are not implemented yet.
    }
    override fun onInterrupt() {}
}
