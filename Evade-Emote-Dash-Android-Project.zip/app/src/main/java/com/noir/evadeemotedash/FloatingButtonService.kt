package com.noir.evadeemotedash

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast

class FloatingButtonService : Service() {
    private lateinit var wm: WindowManager
    private var overlay: Button? = null
    private var params: WindowManager.LayoutParams? = null
    private var downX = 0
    private var downY = 0
    private var startX = 0
    private var startY = 0

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val button = Button(this).apply {
            text = "ED"
            textSize = 14f
            contentDescription = "Evade Emote Dash. Arraste para mover; toque para testar."
            setOnTouchListener { v, event ->
                val p = params ?: return@setOnTouchListener false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX.toInt(); downY = event.rawY.toInt()
                        startX = p.x; startY = p.y
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = startX + event.rawX.toInt() - downX
                        p.y = startY + event.rawY.toInt() - downY
                        wm.updateViewLayout(v, p)
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        val moved = kotlin.math.abs(event.rawX.toInt() - downX) > 8 ||
                            kotlin.math.abs(event.rawY.toInt() - downY) > 8
                        if (!moved) Toast.makeText(this, "Calibração automática ainda não implementada nesta versão alfa.", Toast.LENGTH_LONG).show()
                        true
                    }
                    else -> false
                }
            }
        }
        val type = if (android.os.Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 60; y = 240 }
        params = lp
        overlay = button
        wm.addView(button, lp)
    }

    override fun onDestroy() {
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        overlay = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
