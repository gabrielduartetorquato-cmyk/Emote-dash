plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.noir.evadeemotedash"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.noir.evadeemotedash"
        minSdk = 26
        targetSdk = 28
        versionCode = 1
        versionName = "0.1-alpha"
    }
}
